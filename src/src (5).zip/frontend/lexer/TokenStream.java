package frontend.lexer;

import java.util.ArrayList;

public class TokenStream {
    private final ArrayList<Token> tokens;
    private int index;

    public TokenStream(ArrayList<Token> tokens) {
        this.tokens = tokens;
        index = 0;
    }
    public Token getToken(int index) {
        if(index < 0 || index >= tokens.size()){
            return null;
        }
        return tokens.get(index);
    }

    public Token getCurTokenAndGo() {
        if(index >= tokens.size()){
            return null;
        }
        return tokens.get(index++);
    }

    public Token getCurrentToken() {
        if(index >= tokens.size()){
            return null;
        }
        return tokens.get(index);
    }

    public Token peek(int steps){
        if(index + steps >= tokens.size()){
            return null;
        }
        return tokens.get(index+steps);
    }

    public Token previous(){
        if(index > 0){
            return tokens.get(index-1);
        }
        return null;
    }

    public boolean isParseEnd(){
        return index >= tokens.size();
    }
    //stmt回溯用
    public int getIndex() {
        return this.index;
    }
    public void setIndex(int index) {
        // 这里可以加一些边界检查，确保 index 是合法的
        this.index = index;
    }
}
