package midend.symbol;

import java.util.ArrayList;

public class FuncSymbol extends Symbol {
    private final ArrayList<ValSymbol> params;

    public FuncSymbol(String funcName, SymbolType symbolType, int line,ArrayList<ValSymbol> params) {
        super(funcName, symbolType, line);
        this.params = params;
    }
    public ArrayList<ValSymbol> getParams() {
        return params;
    }
}